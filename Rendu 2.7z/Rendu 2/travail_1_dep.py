import numpy as np
import matplotlib.pyplot as plt
import pandas as pd

# Paramètres globaux
N = 125           # Nombre d'entreprises
S0 = 100          # Prix initial
sigma = 0.4       # Volatilité
T = 1             # 1 an
Nmc = 2000        # Nombre de simulations MC
rho = 0.3         # Corrélation

# Seuils de défaut à étudier
B_list = [100, 50, 36]
VaR_results = {}

# Création de la matrice de covariance corrélée et sa décomposition
Cov = (1 - rho) * np.eye(N) + rho * np.ones((N, N))
M = np.linalg.cholesky(Cov)

# Boucle sur chaque seuil B
for B_ref in B_list:
    pertes = []

    for _ in range(Nmc):
        # Génération du mouvement brownien indépendant
        B_indep = np.random.normal(0, np.sqrt(T), size=N)
        W_corr = M @ B_indep  # Brownien corrélé

        # Simulation des valeurs finales S_i(T)
        S_T = S0 * np.exp(-0.5 * sigma**2 * T + sigma * W_corr)

        # Calcul des pertes X_i = S_i(T) - B
        pertes.extend(S_T - B_ref)

    # Calcul des quantiles pour la VaR
    pertes = np.array(pertes)
    VaR_99 = np.quantile(pertes, 0.01)
    VaR_999 = np.quantile(pertes, 0.001)
    VaR_results[B_ref] = {'VaR_99': VaR_99, 'VaR_999': VaR_999}

# Affichage des résultats
df_VaR = pd.DataFrame([
    {'B': B, 'VaR 99%': res['VaR_99'], 'VaR 99.9%': res['VaR_999']}
    for B, res in VaR_results.items()
])
print(df_VaR)

# Tracé des histogrammes pour comparaison
plt.figure(figsize=(12, 6))
for B_ref in B_list:
    pertes = []
    for _ in range(Nmc):
        B_indep = np.random.normal(0, np.sqrt(T), size=N)
        W_corr = M @ B_indep
        S_T = S0 * np.exp(-0.5 * sigma**2 * T + sigma * W_corr)
        pertes.extend(S_T - B_ref)
    plt.hist(pertes, bins=100, density=True, alpha=0.5, label=f'B = {B_ref}')

plt.axvline(x=VaR_results[100]['VaR_99'], color='r', linestyle='--', label='VaR 99% (B=100)')
plt.axvline(x=VaR_results[50]['VaR_99'], color='g', linestyle='--', label='VaR 99% (B=50)')
plt.axvline(x=VaR_results[36]['VaR_99'], color='b', linestyle='--', label='VaR 99% (B=36)')
plt.xlabel("Pertes X = S(T) - B")
plt.ylabel("Densité")
plt.title("Distribution des pertes pour différents seuils B")
plt.legend()
plt.grid(True)
plt.tight_layout()
plt.savefig("VaR_comparaison_seuils.png")
plt.show()
