#Question 6
import numpy as np
import matplotlib.pyplot as plt
from scipy.stats import beta

# Paramètres globaux
N = 125
S0 = 100
T = 1
Nmc = 100
B_values = [100, 50, 36]
K_values = [1, 5, 10, 20]
rho = 0.3  # Corrélation
mu_R = 0.3
sigma_R = 0.15

# Beta parameters
alpha_beta = ((1 - mu_R)/sigma_R**2 - 1/mu_R) * mu_R**2
beta_beta = alpha_beta * (1/mu_R - 1)

# Volatilité par groupe
def get_sigma(i):
    if 1 <= i <= 25: return 0.2
    elif 26 <= i <= 50: return 0.25
    elif 51 <= i <= 75: return 0.3
    elif 76 <= i <= 100: return 0.35
    elif 101 <= i <= 125: return 0.5
    else: return 0.4

# Matrice de covariance corrélée
Cov = (1 - rho) * np.eye(N) + rho * np.ones((N, N))
M = np.linalg.cholesky(Cov)

def simuler_portefeuille_corr(B, mode_recouvrement='fixe'):
    B_indep = np.random.normal(0, np.sqrt(T), size=N)
    W_corr = M @ B_indep
    S_T = np.zeros(N)

    for i in range(N):
        sigma_i = get_sigma(i + 1)
        S_T[i] = S0 * np.exp(-0.5 * sigma_i**2 * T + sigma_i * W_corr[i])

    L = 0
    PiT = 0.0
    for i in range(N):
        if S_T[i] <= B:
            L += 1
            Ri = 0.3 if mode_recouvrement == 'fixe' else beta.rvs(alpha_beta, beta_beta)
            PiT += Ri * S_T[i]
    return L, PiT

# Simulations
results = {}
for mode in ['fixe', 'beta']:
    results[mode] = {}
    for B in B_values:
        PiT_values = []
        PiT_cond = {K: [] for K in K_values}

        for _ in range(Nmc):
            L, PiT = simuler_portefeuille_corr(B, mode)
            PiT_values.append(PiT)
            for K in K_values:
                if L > K:
                    PiT_cond[K].append(PiT)

        E_PiT_cond = {K: np.mean(PiT_cond[K]) if PiT_cond[K] else 0 for K in K_values}

        results[mode][B] = {
            'E_PiT_cond': E_PiT_cond,
            'PiT_values': PiT_values
        }

# Tracé des fonctions de répartition
plt.figure(figsize=(15, 10))
for i, B in enumerate(B_values):
    for j, mode in enumerate(['fixe', 'beta']):
        plt.subplot(2, 3, i+1 + j*3)
        sorted_PiT = np.sort(results[mode][B]['PiT_values'])
        cdf = np.arange(1, Nmc+1)/Nmc
        plt.plot(sorted_PiT, cdf)
        plt.xlabel('Dette ΠT')
        plt.ylabel('Fonction de répartition')
        plt.title(f'B={B}, Recouvrement {mode} (corrélé)')
        plt.grid(True)
plt.tight_layout()
plt.savefig('fonction_repartition_volatilite_groupe_correle.png')
plt.show()

# Tracé des espérances conditionnelles
plt.figure(figsize=(15, 5))
for k, mode in enumerate(['fixe', 'beta']):
    plt.subplot(1, 2, k+1)
    for B in B_values:
        E_vals = [results[mode][B]['E_PiT_cond'][K] for K in K_values]
        plt.plot(K_values, E_vals, 'o-', label=f'B={B}')
    plt.xlabel('K')
    plt.ylabel('E[ΠT | L > K]')
    plt.title(f'Espérance conditionnelle (Recouvrement {mode}, corrélé)')
    plt.legend()
    plt.grid(True)
plt.tight_layout()
plt.savefig('esperance_conditionnelle_volatilite_groupe_correle.png')
plt.show()

# Affichage des résultats
print("=== Résultats numériques (cas corrélé avec volatilité hétérogène) ===")
for mode in ['fixe', 'beta']:
    print(f"\nMode de recouvrement : {mode}")
    for B in B_values:
        print(f"\nPour B = {B}:")
        for K in K_values:
            val = results[mode][B]['E_PiT_cond'][K]
            print(f"E[ΠT | L > {K}] = {val:.2f}")
