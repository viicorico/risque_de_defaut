import numpy as np
import matplotlib.pyplot as plt
import math

#Question 2
# Paramètres
N = 125
S0 = 100
sigma = 0.4
T = 1
dt = T / 365
Nmc = 2000
rho = 0.3  # corrélation entre entreprises

# Construction de la matrice de covariance corrélée et décomposition de Cholesky
Cov = (1 - rho) * np.eye(N) + rho * np.ones((N, N))
M = np.linalg.cholesky(Cov)

def simuler_ST_corr():
    """Simule les S_i(T) corrélés pour N entreprises"""
    # Générer B_j(T) ~ N(0, T)
    B_T = np.random.normal(0, math.sqrt(T), size=N)
    W_corr = M @ B_T  # Brownien corrélé W_i(T)

    # Calcul de S_i(T)
    S_T = S0 * np.exp(-0.5 * sigma**2 * T + sigma * W_corr)
    return S_T

def calculer_P_L_sup_K_corr(B, K_max, Nmc):
    """Calcule P(L ≥ K) dans le cas corrélé"""
    counts = np.zeros(K_max + 1)

    for _ in range(Nmc):
        S_T = simuler_ST_corr()
        L = np.sum(S_T <= B)

        for K in range(1, min(L, K_max) + 1):
            counts[K] += 1

    return counts / Nmc

# Tracé des résultats
plt.figure(figsize=(15, 5))

# Cas 1 : B = 100
plt.subplot(1, 3, 1)
B1, K_max1 = 100, 100
probas1 = calculer_P_L_sup_K_corr(B1, K_max1, Nmc)
plt.plot(range(1, K_max1 + 1), probas1[1:], 'b-')
plt.xlabel('K')
plt.ylabel('P(L ≥ K)')
plt.title(f'B = {B1}')
plt.grid(True)

# Cas 2 : B = 50
plt.subplot(1, 3, 2)
B2, K_max2 = 50, 20
probas2 = calculer_P_L_sup_K_corr(B2, K_max2, Nmc)
plt.plot(range(1, K_max2 + 1), probas2[1:], 'r-')
plt.xlabel('K')
plt.title(f'B = {B2}')
plt.grid(True)

# Cas 3 : B = 36
plt.subplot(1, 3, 3)
B3, K_max3 = 36, 10
probas3 = calculer_P_L_sup_K_corr(B3, K_max3, Nmc)
plt.plot(range(1, K_max3 + 1), probas3[1:], 'g-')
plt.xlabel('K')
plt.title(f'B = {B3}')
plt.grid(True)

plt.tight_layout()
plt.savefig('probabilites_defauts_corr.png')
plt.show()

# Affichage numérique
print("=== Probabilités P(L ≥ K) – cas corrélé ===")
print(f"\nPour B = {B1}:")
for K in [1, 10, 50, 100]:
    if K <= K_max1:
        print(f"P(L ≥ {K}) = {probas1[K]:.4f}")

print(f"\nPour B = {B2}:")
for K in [1, 5, 10, 20]:
    print(f"P(L ≥ {K}) = {probas2[K]:.4f}")

print(f"\nPour B = {B3}:")
for K in [1, 3, 5, 10]:
    print(f"P(L ≥ {K}) = {probas3[K]:.4f}")
