import numpy as np
import matplotlib.pyplot as plt

#Question 4

# Paramètres
N = 125
S0 = 100
sigma = 0.4
T = 1
Nmc = 100
dt = T / N
B_values = [100, 50, 36]
K_values = [1, 5, 10, 20]
Ri = 0.4
rho = 0.5  # Corrélation modifiée ici

# Matrice de covariance et décomposition de Cholesky
Cov = (1 - rho) * np.eye(N) + rho * np.ones((N, N))
M = np.linalg.cholesky(Cov)

def simuler_portefeuille_corr(B):
    B_indep = np.random.normal(0, np.sqrt(T), size=N)
    W_corr = M @ B_indep
    S_T = S0 * np.exp(-0.5 * sigma**2 * T + sigma * W_corr)
    L = np.sum(S_T <= B)
    PiT = np.sum([Ri * S_T[i] for i in range(N) if S_T[i] <= B])
    return L, PiT

# Simulations
results = {}
for B in B_values:
    L_counts = np.zeros(N + 1)
    PiT_values = []
    PiT_cond = {K: [] for K in K_values}

    for _ in range(Nmc):
        L, PiT = simuler_portefeuille_corr(B)
        L_counts[L] += 1
        PiT_values.append(PiT)
        for K in K_values:
            if L > K:
                PiT_cond[K].append(PiT)

    E_PiT_cond = {K: np.mean(PiT_cond[K]) if PiT_cond[K] else 0 for K in K_values}
    sorted_PiT = np.sort(PiT_values)
    cdf = np.arange(1, Nmc + 1) / Nmc

    results[B] = {
        'E_PiT_cond': E_PiT_cond,
        'PiT_values': PiT_values,
        'sorted_PiT': sorted_PiT,
        'cdf': cdf
    }

# Affichage des résultats numériques
print("=== Résultats numériques (corrélation 0.5) ===")
for B in B_values:
    print(f"\nPour B = {B}:")
    for K in K_values:
        print(f"E[ΠT | L > {K}] = {results[B]['E_PiT_cond'][K]:.2f}")

# Graphe 1 : Fonction de répartition de ΠT
plt.figure(figsize=(10, 6))
for B in B_values:
    plt.plot(results[B]['sorted_PiT'], results[B]['cdf'], label=f'B = {B}')
plt.xlabel('Dette ΠT')
plt.ylabel('Fonction de répartition')
plt.title('Fonction de répartition empirique de ΠT (corrélation 0.5)')
plt.grid(True)
plt.legend()
plt.tight_layout()
plt.savefig("fonction_repartition_PiT_correlation_05.png")
plt.show()

# Graphe 2 : Espérance conditionnelle de ΠT
plt.figure(figsize=(10, 6))
for B in B_values:
    E_vals = [results[B]['E_PiT_cond'][K] for K in K_values]
    plt.plot(K_values, E_vals, marker='o', label=f'B = {B}')
plt.xlabel('K')
plt.ylabel('E[ΠT | L > K]')
plt.title("Espérance conditionnelle de la dette ΠT (corrélation 0.5)")
plt.grid(True)
plt.legend()
plt.tight_layout()
plt.savefig("esperance_conditionnelle_PiT_correlation_05.png")
plt.show()
