import numpy as np
import matplotlib.pyplot as plt
import math

# Paramètres globaux
S0 = 100      # Prix initial de l'actif
sigma = 0.4   # Volatilité
r = 0.0       # Taux d'intérêt

def simuler_S_T(S0, r, sigma, T):
    """
    Simule S_T selon un mouvement brownien géométrique.
    S_T = S0 * exp((r - 0.5*sigma^2)*T + sigma*sqrt(T)*Y) avec Y ~ N(0,1)
    """
    Y = np.random.normal(0, 1)
    S_T = S0 * math.exp((r - 0.5 * sigma**2) * T + sigma * math.sqrt(T) * Y)
    return S_T

def psi(z, x):
    """Fonction indicatrice : retourne 1 si x <= z, sinon 0."""
    return 1 if x <= z else 0

def robbins_monro_var(S0, r, sigma, Nmc, alpha, B, T, beta, z0):
    """
    Implémente l'algorithme de Robbins-Monro pour trouver z* tel que P(X ≤ z*) = α,
    où X = S_T - B et S_T est simulé selon le modèle de mouvement brownien géométrique.
    
    Arguments :
      S0, r, sigma : paramètres de l'actif (utilisés dans simuler_S_T)
      Nmc         : nombre d'itérations (simulations Monte-Carlo)
      alpha       : niveau de confiance (ex : 0.01 pour 1%)
      B           : seuil, avec X = S_T - B
      T           : horizon de temps
      beta        : paramètre du pas d'apprentissage
      z0          : estimation initiale
      
    Retourne :
      final_z : dernière valeur de z (z[-1])
      history : liste complète des valeurs de z sur toutes les itérations
    """
    Z = [z0]
    gamma = [beta / ((n + 1) ** 0.9) for n in range(Nmc)]
    for n in range(Nmc):
        S_T = simuler_S_T(S0, r, sigma, T)
        X_n = S_T - B
        psi_val = psi(Z[n], X_n)
        Z_next = Z[n] - gamma[n] * (psi_val - alpha)
        Z.append(Z_next)
    return Z[-1], Z

def main():
    # Paramètres pour la simulation dans main()
    Nmc = 10000       # Nombre d'itérations pour l'algorithme
    beta = 1.0        # Paramètre du pas d'apprentissage
    z0 = 0.0          # Estimation initiale
    
    # Liste des cas de test : (B, alpha, T, description)
    cas_test = [
        (100, 0.01, 1.0,   "B=100, α=1%, T=1 an"),
        (100, 0.001, 1.0,  "B=100, α=0.1%, T=1 an"),
        (100, 0.01, 10/365,"B=100, α=1%, T=10 jours"),
        (100, 0.001, 10/365,"B=100, α=0.1%, T=10 jours"),
        (50, 0.01, 1.0,   "B=50, α=1%, T=1 an"),
        (50, 0.001, 1.0,  "B=50, α=0.1%, T=1 an"),
        (36, 0.01, 1.0,   "B=36, α=1%, T=1 an")
    ]
    
    print("=== Travail 4 : Estimation de VaR par Robbins-Monro ===")
    for B, alpha, T, description in cas_test:
        final_z, history = robbins_monro_var(S0, r, sigma, Nmc, alpha, B, T, beta, z0)
        # Pour de faibles niveaux de confiance, z* sera négatif (indiquant une perte)
        VaR = -final_z if final_z < 0 else 0
        print(f"{description} -> VaR estimée : {VaR:.4f} euros")
        
        # Tracé de la convergence de la suite z
        plt.figure(figsize=(10, 6))
        plt.plot(history, lw=2, label="Évolution de z")
        plt.xlabel("Itérations")
        plt.ylabel("z (VaR non corrigée)")
        plt.title(f"Convergence de VaR ({description})")
        plt.grid(True)
        plt.legend()
        
        #Sauvegarde de graphe
        filename = f"Convergence_VaR_B{B}_alpha{alpha}_T{T:.4f}_beta{beta}_z0{z0}.png"
        plt.savefig(filename, dpi=300, bbox_inches="tight")
        print(f"Graphique sauvegardé sous : {filename}")
        
        plt.show()
        plt.close()

if __name__ == "__main__":
    main()
