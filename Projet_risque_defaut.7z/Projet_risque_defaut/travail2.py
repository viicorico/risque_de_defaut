import numpy as np
import matplotlib.pyplot as plt
import math

T = 1       # 1 an
N = 125
S0 = 100
sigma = 0.4

def generer_mouvement_brownien():
    W = [0]
    delta_t = T / N
    for i in range(N):
        W_i = W[i] + np.sqrt(delta_t) * np.random.normal(0, 1)
        W.append(W_i)
    return W

def simuler_S():
    delta_t = T / N
    t = [i * delta_t for i in range(N + 1)]
    W = generer_mouvement_brownien()
    S = [S0 * math.exp(-0.5 * sigma ** 2 * t[i] + sigma * W[i]) for i in range(N + 1)]
    return t, S

def simuler_S_Nmc(Nmc):
    plt.figure(figsize=(10, 5))
    for _ in range(Nmc):
        t, S = simuler_S()
        plt.plot(t, S, alpha=0.5)
    plt.xlabel("Temps (t)")
    plt.ylabel("S(t)")
    plt.title(f"Simulation de {Nmc} trajectoires de S(t)")
    plt.grid(True)
    # Sauvegarde du graphe des trajectoires (optionnel)
    filename = f"trajectoires_S_t_{Nmc}.png"
    plt.savefig(filename, dpi=300, bbox_inches="tight")
    print(f"Graphique des trajectoires sauvegardé sous : {filename}")
    plt.show()
    plt.close()

# (Optionnel) Exécution de la simulation des trajectoires
# simuler_S_Nmc(10000)

# Calculer X = S_T - B pour Nmc simulations
def tab_X(Nmc, B):
    X = []
    for _ in range(Nmc):
        S_T = simuler_S()[1][-1]  # Dernière valeur de S
        X.append(S_T - B)
    return X

def F(X, a, b, Nx, Nmc):
    x = []
    proba = []
    for i in range(Nx):
        x_val = a + (b - a) * i / Nx
        x.append(x_val)
        compteur = 0
        for j in range(Nmc):
            if X[j] <= x_val:
                compteur += 1
        proba.append(compteur / Nmc)
    return x, proba

# Fonction pour calculer la densité empirique (PDF) via histogramme
def densite_empirique(X, Nx):
    hist, bin_edges = np.histogram(X, bins=Nx, density=True)
    x_centers = (bin_edges[:-1] + bin_edges[1:]) / 2
    return x_centers, hist

# -----------------------------------------------------
# Partie 1 : Simulation de la fonction de répartition (CDF)
# -----------------------------------------------------
print("=== Simulation de la fonction de répartition de X = S_T - B ===")
Nmc_cdf = 10000
Nx = 100
B_values_cdf = [100, 50, 36]

for B in B_values_cdf:
    X = tab_X(Nmc_cdf, B)
    a_val, b_val = min(X), max(X)
    x_vals, cdf_vals = F(X, a_val, b_val, Nx, Nmc_cdf)
    
    plt.figure(figsize=(10, 6))
    plt.plot(x_vals, cdf_vals, lw=2, label=f"Fontion répartition, B = {B}")
    plt.xlabel("x")
    plt.ylabel("F_X(x) = P(X ≤ x)")
    plt.title(f"Fonction de répartition empirique de X = S_T - B (B = {B})")
    plt.grid(True)
    plt.legend()
    
    filename_cdf = f"repartition_B_{B}_Nmc_{Nmc_cdf}.png"
    plt.savefig(filename_cdf, dpi=300, bbox_inches="tight")
    print(f"Graphique répartition sauvegardé sous : {filename_cdf}")
    
    plt.show()
    plt.close()

# -----------------------------------------------------
# Partie 2 : Simulation de la fonction de densité (PDF)
# -----------------------------------------------------
print("=== Simulation de la densite de X = S_T - B ===")
Nmc_pdf = 10000
B_values_pdf = [100, 50, 36]

for B in B_values_pdf:
    X = tab_X(Nmc_pdf, B)
    x_centers, density_vals = densite_empirique(X, Nx)
    
    plt.figure(figsize=(10, 6))
    plt.plot(x_centers, density_vals, lw=2, label=f"densité, B = {B}")
    plt.xlabel("x")
    plt.ylabel("f_X(x)")
    plt.title(f"Fonction de densité empirique de X = S_T - B (B = {B})")
    plt.grid(True)
    plt.legend()
    
    filename_pdf = f"densite_B_{B}_Nmc_{Nmc_pdf}.png"
    plt.savefig(filename_pdf, dpi=300, bbox_inches="tight")
    print(f"Graphique densité sauvegardé sous : {filename_pdf}")
    
    plt.show()
    plt.close()
