import numpy as np
import math
import matplotlib.pyplot as plt

# Paramètres selon les consignes
N = 125       # Nombre d'entreprises
S0 = 100      # Prix initial pour chaque entreprise
sigma = 0.4   # Volatilité commune
T = 1         # Horizon temporel (1 an = 365 jours)
dt = T/365    # Pas de temps quotidien
Nmc = 100     # Nombre de simulations Monte Carlo

# Fonctions du rendu 1 (sans modification)
def generer_mouvement_brownien():
    """Génère un mouvement brownien standard pour une entreprise"""
    W = [0]
    for _ in range(365):  # 365 jours
        W_i = W[-1] + np.random.normal(0, math.sqrt(dt))
        W.append(W_i)
    return W

def simuler_Si():
    """Simule le prix d'une entreprise selon le modèle géométrique brownien"""
    W = generer_mouvement_brownien()
    t = T  # On ne regarde qu'à l'horizon T
    Si_T = S0 * math.exp(-0.5 * sigma**2 * t + sigma * W[-1])
    return Si_T

def calculer_P_L_sup_K(B, K_max, Nmc):
    """Calcule P(L ≥ K) pour K ∈ [1, K_max]"""
    counts = np.zeros(K_max + 1)  # Pour stocker le nombre de simulations où L ≥ K
    
    for _ in range(Nmc):
        # Compter le nombre de défauts pour cette simulation
        L = 0
        for _ in range(N):  # Pour chaque entreprise
            Si_T = simuler_Si()
            if Si_T <= B:
                L += 1
        
        # Mettre à jour les comptes
        for K in range(1, min(L, K_max) + 1):
            counts[K] += 1
    
    # Calcul des probabilités
    probas = counts / Nmc
    return probas

# Calculs et tracés pour chaque cas
plt.figure(figsize=(15, 5))

# Cas 1: B = 100, K ∈ [1, 100]
plt.subplot(1, 3, 1)
B1 = 100
K_max1 = 100
probas1 = calculer_P_L_sup_K(B1, K_max1, Nmc)
plt.plot(range(1, K_max1+1), probas1[1:], 'b-')
plt.xlabel('K')
plt.ylabel('P(L ≥ K)')
plt.title(f'B = {B1}')
plt.grid(True)

# Cas 2: B = 50, K ∈ [1, 20]
plt.subplot(1, 3, 2)
B2 = 50
K_max2 = 20
probas2 = calculer_P_L_sup_K(B2, K_max2, Nmc)
plt.plot(range(1, K_max2+1), probas2[1:], 'r-')
plt.xlabel('K')
plt.title(f'B = {B2}')
plt.grid(True)

# Cas 3: B = 36, K ∈ [1, 10]
plt.subplot(1, 3, 3)
B3 = 36
K_max3 = 10
probas3 = calculer_P_L_sup_K(B3, K_max3, Nmc)
plt.plot(range(1, K_max3+1), probas3[1:], 'g-')
plt.xlabel('K')
plt.title(f'B = {B3}')
plt.grid(True)

plt.tight_layout()
plt.savefig('probabilites_defauts.png')
plt.show()

# Affichage des valeurs numériques
print("=== Probabilités P(L ≥ K) ===")
print(f"\nPour B = {B1}:")
for K in [1, 10, 50, 100]:
    if K <= K_max1:
        print(f"P(L ≥ {K}) = {probas1[K]:.4f}")

print(f"\nPour B = {B2}:")
for K in [1, 5, 10, 20]:
    print(f"P(L ≥ {K}) = {probas2[K]:.4f}")

print(f"\nPour B = {B3}:")
for K in [1, 3, 5, 10]:
    print(f"P(L ≥ {K}) = {probas3[K]:.4f}")