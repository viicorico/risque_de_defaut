import numpy as np
import math
import matplotlib.pyplot as plt

# Fonctions du rendu 1 (sans modification)
def generer_mouvement_brownien():
    """Génère un mouvement brownien standard"""
    W = [0]
    for _ in range(N):
        W_i = W[-1] + np.sqrt(dt) * np.random.normal(0, 1)
        W.append(W_i)
    return W

def simuler_S():
    """Simule une trajectoire de S(t) et retourne S_T"""
    t = [i * dt for i in range(N + 1)]
    W = generer_mouvement_brownien()
    S = [S0 * math.exp(-0.5 * sigma ** 2 * t[i] + sigma * W[i]) for i in range(N + 1)]
    return t, S

# Paramètres globaux
N = 125       # Nombre d'entreprises
S0 = 100      # Prix initial
sigma = 0.4   # Volatilité
T = 1         # Horizon temporel (1 an)
dt = T/N      # Pas de temps
Nmc = 100   # Nombre de simulations Monte Carlo
B_values = [100, 50, 36]  # Seuils de défaut
K_values = [1, 5, 10, 20] # Valeurs de K pour le conditionnement
Ri = 0.4      # Taux de recouvrement fixé

def simuler_portefeuille(B):
    """Simule un portefeuille et retourne L et ΠT"""
    L = 0
    PiT = 0.0
    for _ in range(N):
        _, S = simuler_S()
        S_T = S[-1]
        if S_T <= B:
            L += 1
            PiT += Ri * S_T
    return L, PiT

# Calculs pour chaque seuil B
results = {}
for B in B_values:
    # Stockage des résultats
    L_counts = np.zeros(N+1)
    PiT_values = []
    PiT_cond = {K: [] for K in K_values}
    
    for _ in range(Nmc):
        L, PiT = simuler_portefeuille(B)
        L_counts[L] += 1
        PiT_values.append(PiT)
        
        # Stockage conditionnel pour chaque K
        for K in K_values:
            if L > K:
                PiT_cond[K].append(PiT)
    
    # Calcul des espérances conditionnelles
    E_PiT_cond = {K: np.mean(PiT_cond[K]) if PiT_cond[K] else 0 for K in K_values}
    
    # Calcul de la fonction de répartition de ΠT
    sorted_PiT = np.sort(PiT_values)
    cdf = np.arange(1, Nmc+1) / Nmc
    
    results[B] = {
        'E_PiT_cond': E_PiT_cond,
        'PiT_values': PiT_values,
        'sorted_PiT': sorted_PiT,
        'cdf': cdf
    }

# Tracé des fonctions de répartition
plt.figure(figsize=(15, 5))
for i, B in enumerate(B_values):
    plt.subplot(1, 3, i+1)
    plt.plot(results[B]['sorted_PiT'], results[B]['cdf'])
    plt.xlabel('Dette ΠT')
    plt.ylabel('Fonction de répartition')
    plt.title(f'Fonction de répartition de ΠT (B={B})')
    plt.grid(True)
plt.tight_layout()
plt.savefig('fonction_repartition_dette.png')
plt.show()

# Tracé des espérances conditionnelles
plt.figure(figsize=(10, 6))
for B in B_values:
    E_vals = [results[B]['E_PiT_cond'][K] for K in K_values]
    plt.plot(K_values, E_vals, 'o-', label=f'B={B}')
plt.xlabel('K')
plt.ylabel('E[ΠT | L > K]')
plt.title('Espérance conditionnelle de la dette')
plt.legend()
plt.grid(True)
plt.savefig('esperance_conditionnelle_dette.png')
plt.show()

# Affichage des résultats numériques
print("=== Résultats numériques ===")
for B in B_values:
    print(f"\nPour B = {B}:")
    for K in K_values:
        print(f"E[ΠT | L > {K}] = {results[B]['E_PiT_cond'][K]:.2f}")