import numpy as np
import math
import matplotlib.pyplot as plt
from scipy.stats import beta

# Fonctions du rendu 1 (sans modification)
def generer_mouvement_brownien():
    """Génère un mouvement brownien standard"""
    W = [0]
    for _ in range(N):
        W_i = W[-1] + np.sqrt(dt) * np.random.normal(0, 1)
        W.append(W_i)
    return W

def simuler_S():
    """Simule une trajectoire de S(t) et retourne S_T"""
    t = [i * dt for i in range(N + 1)]
    W = generer_mouvement_brownien()
    S = [S0 * math.exp(-0.5 * sigma**2 * t[i] + sigma * W[i]) for i in range(N + 1)]
    return t, S

# Paramètres globaux
N = 125       # Nombre d'entreprises
S0 = 100      # Prix initial
sigma = 0.4   # Volatilité
T = 1         # Horizon temporel (1 an)
dt = T/N      # Pas de temps
Nmc = 100   # Nombre de simulations Monte Carlo
B_values = [100, 50, 36]  # Seuils de défaut
K_values = [1, 5, 10, 20] # Valeurs de K pour le conditionnement

# Paramètres pour le cas Beta
mu_R = 0.3    # Moyenne 30%
sigma_R = 0.15 # Écart-type 15%

# Calcul des paramètres alpha et beta pour la distribution Beta
alpha_beta = ((1 - mu_R)/sigma_R**2 - 1/mu_R) * mu_R**2
beta_beta = alpha_beta * (1/mu_R - 1)

def simuler_portefeuille(B, mode_recouvrement='fixe'):
    """Simule un portefeuille et retourne L et ΠT"""
    L = 0
    PiT = 0.0
    
    for _ in range(N):
        _, S = simuler_S()
        S_T = S[-1]
        if S_T <= B:
            L += 1
            if mode_recouvrement == 'fixe':
                Ri = 0.3  # Taux fixe à 30%
            else:
                Ri = beta.rvs(alpha_beta, beta_beta)  # Loi Beta
            PiT += Ri * S_T
    return L, PiT

# Calculs pour chaque seuil B et chaque mode de recouvrement
results = {}
for mode in ['fixe', 'beta']:
    results[mode] = {}
    for B in B_values:
        # Stockage des résultats
        PiT_values = []
        PiT_cond = {K: [] for K in K_values}
        
        for _ in range(Nmc):
            L, PiT = simuler_portefeuille(B, mode)
            PiT_values.append(PiT)
            
            # Stockage conditionnel pour chaque K
            for K in K_values:
                if L > K:
                    PiT_cond[K].append(PiT)
        
        # Calcul des espérances conditionnelles
        E_PiT_cond = {K: np.mean(PiT_cond[K]) if PiT_cond[K] else 0 for K in K_values}
        
        results[mode][B] = {
            'E_PiT_cond': E_PiT_cond,
            'PiT_values': PiT_values
        }

# Tracé des fonctions de répartition
plt.figure(figsize=(15, 10))
for i, B in enumerate(B_values):
    for j, mode in enumerate(['fixe', 'beta']):
        plt.subplot(2, 3, i+1 + j*3)
        sorted_PiT = np.sort(results[mode][B]['PiT_values'])
        cdf = np.arange(1, Nmc+1)/Nmc
        plt.plot(sorted_PiT, cdf)
        plt.xlabel('Dette ΠT')
        plt.ylabel('Fonction de répartition')
        plt.title(f'B={B}, Recouvrement {mode}')
        plt.grid(True)
plt.tight_layout()
plt.savefig('fonction_repartition_comparison.png')
plt.show()

# Tracé des espérances conditionnelles
plt.figure(figsize=(15, 5))
for k, mode in enumerate(['fixe', 'beta']):
    plt.subplot(1, 2, k+1)
    for B in B_values:
        E_vals = [results[mode][B]['E_PiT_cond'][K] for K in K_values]
        plt.plot(K_values, E_vals, 'o-', label=f'B={B}')
    plt.xlabel('K')
    plt.ylabel('E[ΠT | L > K]')
    plt.title(f'Espérance conditionnelle (Recouvrement {mode})')
    plt.legend()
    plt.grid(True)
plt.tight_layout()
plt.savefig('esperance_conditionnelle_comparison.png')
plt.show()

# Affichage des résultats numériques
print("=== Résultats numériques ===")
for mode in ['fixe', 'beta']:
    print(f"\nMode de recouvrement: {mode}")
    for B in B_values:
        print(f"\nPour B = {B}:")
        for K in K_values:
            val = results[mode][B]['E_PiT_cond'][K]
            print(f"E[ΠT | L > {K}] = {val:.2f}")