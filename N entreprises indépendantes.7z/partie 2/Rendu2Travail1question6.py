import numpy as np
import math
import matplotlib.pyplot as plt

# Fonctions du rendu 1 (sans modification)
def generer_mouvement_brownien():
    """Génère un mouvement brownien standard"""
    W = [0]
    for _ in range(N):
        W_i = W[-1] + np.sqrt(dt) * np.random.normal(0, 1)
        W.append(W_i)
    return W

def simuler_S(sigma):
    """Simule une trajectoire de S(t) avec une volatilité spécifique et retourne S_T"""
    t = [i * dt for i in range(N + 1)]
    W = generer_mouvement_brownien()
    S = [S0 * math.exp(-0.5 * sigma**2 * t[i] + sigma * W[i]) for i in range(N + 1)]
    return t, S

def beta_pdf(x, alpha, beta):
    """Calcule la densité de la loi Beta"""
    if x < 0 or x > 1:
        return 0
    return (x**(alpha-1)) * ((1-x)**(beta-1)) / beta_function(alpha, beta)

def beta_function(alpha, beta):
    """Calcule la fonction Beta"""
    return math.gamma(alpha) * math.gamma(beta) / math.gamma(alpha + beta)

def simulate_beta_rejection(alpha, beta, Nmc):
    """Simule des variables aléatoires suivant une loi Beta par rejet"""
    Y = []
    x0 = (alpha-1)/(alpha+beta-2) if (alpha+beta) != 2 else 0.5
    C = beta_pdf(x0, alpha, beta)
    for _ in range(Nmc):
        while True:
            U = np.random.uniform(0, 1)
            Y_candidate = np.random.uniform(0, 1)
            if U <= beta_pdf(Y_candidate, alpha, beta) / C:
                Y.append(Y_candidate)
                break
    return Y

# Paramètres globaux
N = 125       # Nombre d'entreprises
S0 = 100      # Prix initial
T = 1         # Horizon temporel (1 an)
dt = T/N      # Pas de temps
Nmc = 100   # Nombre de simulations Monte Carlo
B_values = [100, 50, 36]  # Seuils de défaut
K_values = [1, 5, 10, 20] # Valeurs de K pour le conditionnement

# Structure de volatilité par groupe d'entreprises
def get_sigma(i):
    """Retourne la volatilité selon le groupe d'entreprise"""
    if 1 <= i <= 25: return 0.2
    elif 26 <= i <= 50: return 0.25
    elif 51 <= i <= 75: return 0.3
    elif 76 <= i <= 100: return 0.35
    elif 101 <= i <= 125: return 0.5
    else: return 0.4  # Valeur par défaut

# Paramètres pour le taux de recouvrement Beta
mu_R = 0.3    # Moyenne 30%
sigma_R = 0.15 # Écart-type 15%

# Calcul des paramètres alpha et beta pour la distribution Beta
alpha_beta = ((1 - mu_R)/sigma_R**2 - 1/mu_R) * mu_R**2
beta_beta = alpha_beta * (1/mu_R - 1)

def simuler_portefeuille(B, mode_recouvrement='fixe'):
    """Simule un portefeuille et retourne L et ΠT"""
    L = 0
    PiT = 0.0
    
    for i in range(1, N+1):  # Pour chaque entreprise
        sigma_i = get_sigma(i)
        _, S = simuler_S(sigma_i)
        S_T = S[-1]
        if S_T <= B:
            L += 1
            if mode_recouvrement == 'fixe':
                Ri = 0.3  # Taux fixe à 30%
            else:
                # Simulation du taux de recouvrement par Beta
                Ri = simulate_beta_rejection(alpha_beta, beta_beta, 1)[0]
            PiT += Ri * S_T
    return L, PiT

# Calculs pour chaque seuil B et chaque mode de recouvrement
results = {}
for mode in ['fixe', 'beta']:
    results[mode] = {}
    for B in B_values:
        # Stockage des résultats
        PiT_values = []
        PiT_cond = {K: [] for K in K_values}
        
        for _ in range(Nmc):
            L, PiT = simuler_portefeuille(B, mode)
            PiT_values.append(PiT)
            
            # Stockage conditionnel pour chaque K
            for K in K_values:
                if L > K:
                    PiT_cond[K].append(PiT)
        
        # Calcul des espérances conditionnelles
        E_PiT_cond = {K: np.mean(PiT_cond[K]) if PiT_cond[K] else 0 for K in K_values}
        
        results[mode][B] = {
            'E_PiT_cond': E_PiT_cond,
            'PiT_values': PiT_values
        }

# Tracé des fonctions de répartition
plt.figure(figsize=(15, 10))
for i, B in enumerate(B_values):
    for j, mode in enumerate(['fixe', 'beta']):
        plt.subplot(2, 3, i+1 + j*3)
        sorted_PiT = np.sort(results[mode][B]['PiT_values'])
        cdf = np.arange(1, Nmc+1)/Nmc
        plt.plot(sorted_PiT, cdf)
        plt.xlabel('Dette ΠT')
        plt.ylabel('Fonction de répartition')
        plt.title(f'B={B}, Recouvrement {mode}')
        plt.grid(True)
plt.tight_layout()
plt.savefig('fonction_repartition_volatilite_groupe.png')
plt.show()

# Tracé des espérances conditionnelles
plt.figure(figsize=(15, 5))
for k, mode in enumerate(['fixe', 'beta']):
    plt.subplot(1, 2, k+1)
    for B in B_values:
        E_vals = [results[mode][B]['E_PiT_cond'][K] for K in K_values]
        plt.plot(K_values, E_vals, 'o-', label=f'B={B}')
    plt.xlabel('K')
    plt.ylabel('E[ΠT | L > K]')
    plt.title(f'Espérance conditionnelle (Recouvrement {mode})')
    plt.legend()
    plt.grid(True)
plt.tight_layout()
plt.savefig('esperance_conditionnelle_volatilite_groupe.png')
plt.show()

# Affichage des résultats numériques
print("=== Résultats numériques ===")
for mode in ['fixe', 'beta']:
    print(f"\nMode de recouvrement: {mode}")
    for B in B_values:
        print(f"\nPour B = {B}:")
        for K in K_values:
            val = results[mode][B]['E_PiT_cond'][K]
            print(f"E[ΠT | L > {K}] = {val:.2f}")