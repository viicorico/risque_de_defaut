import numpy as np
import matplotlib.pyplot as plt
import math

# Réutilisation de vos fonctions existantes sans modification
def simuler_S():
    """Simule une trajectoire de S(t) et retourne S_T"""
    delta_t = T / N
    t = [i * delta_t for i in range(N + 1)]
    W = generer_mouvement_brownien()
    S = [S0 * math.exp(-0.5 * sigma ** 2 * t[i] + sigma * W[i]) for i in range(N + 1)]
    return t, S

def generer_mouvement_brownien():
    """Génère un mouvement brownien standard"""
    W = [0]
    for _ in range(N):
        W_i = W[-1] + np.sqrt(dt) * np.random.normal(0, 1)
        W.append(W_i)
    return W

# Paramètres globaux (à adapter selon vos besoins)
S0 = 100       # Prix initial
sigma = 0.4    # Volatilité
T = 1          # Horizon temporel (1 an)
N = 100        # Nombre de pas de temps
dt = T/N       # Pas de temps
B = 100        # Seuil de référence
Nmc = 10   # Nombre de simulations Monte Carlo

def calculer_VaR_MC(alpha, Nmc, B):
    """
    Calcule la VaR par simulation Monte Carlo
    Paramètres:
    - alpha: niveau de risque (ex: 0.05 pour VaR 95%)
    - Nmc: nombre de simulations
    - B: seuil de référence (X = S_T - B)
    Retourne:
    - VaR: valeur à risque
    - pertes: array des pertes simulées (pour analyse)
    """
    pertes = []
    
    for _ in range(Nmc):
        # Simulation de S_T en utilisant votre fonction existante
        _, S = simuler_S()
        S_T = S[-1]  # Dernière valeur = S(T)
        
        # Calcul de la perte X = S_T - B
        X = S_T - B
        pertes.append(X)
    
    # Conversion en array numpy pour le calcul des quantiles
    pertes = np.array(pertes)
    
    # Calcul de la VaR (quantile alpha des pertes)
    VaR = np.quantile(pertes, alpha)
    
    return VaR, pertes

# Calcul des VaR pour les deux seuils de confiance
VaR_95, pertes_95 = calculer_VaR_MC(0.05, Nmc, B)  # 1-alpha = 95% => alpha = 5%
VaR_999, pertes_999 = calculer_VaR_MC(0.001, Nmc, B)  # 1-alpha = 99.9% => alpha = 0.1%

# Affichage des résultats
print(f"VaR à 95% de confiance: {VaR_95:.4f}")
print(f"VaR à 99.9% de confiance: {VaR_999:.4f}")

# Visualisation des distributions des pertes
plt.figure(figsize=(12, 6))

# Histogramme des pertes
plt.hist(pertes_95, bins=100, density=True, alpha=0.7, label='Distribution des pertes')

# Lignes verticales pour les VaR
plt.axvline(x=VaR_95, color='r', linestyle='--', label=f'VaR 95% = {VaR_95:.2f}')
plt.axvline(x=VaR_999, color='g', linestyle='--', label=f'VaR 99.9% = {VaR_999:.2f}')

plt.xlabel('Pertes (X = S_T - B)')
plt.ylabel('Densité de probabilité')
plt.title('Distribution des pertes et Valeurs à Risque (VaR)')
plt.legend()
plt.grid(True)

# Sauvegarde du graphique
filename = f"VaR_comparison_B{B}_Nmc{Nmc}.png"
plt.savefig(filename, dpi=300, bbox_inches='tight')
print(f"Graphique sauvegardé sous: {filename}")
plt.show()
plt.close()